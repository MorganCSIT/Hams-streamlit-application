@echo off
chcp 65001
"..\nx-spi-client\Asebis.Client.StarterCommand.exe" /u=nexus /p=fAvNCDnW3E /t=ImportLeistungen_CSV /o=100000000000000301 /f="2027-Soler Fanny+6170.csv" /map="..\..\HAS_map_main.csv" /v
Pause
